# OTP-Verification-in-E-mail
Give your website the most security by One Time Password(OTP) Verification.  Written in PHP 5.0. OTP will be dropped in your registered email.

Start by running the 'otp.html' file in your server. 

